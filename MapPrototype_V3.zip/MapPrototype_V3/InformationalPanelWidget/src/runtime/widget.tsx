/** @jsx jsx */
import { React, AllWidgetProps, jsx } from 'jimu-core';
import scenarioData from '../data/scenario.json';
import eventEmitter from '../../../PennRoadSegments/src/singleton/EventEmitterInstance';

// Utility for formatting numbers.
function formatNumber(value: number, isCurrency?: boolean) {
  if (value == null || isNaN(value)) return '';
  return new Intl.NumberFormat('en-US', {
    style: isCurrency ? 'currency' : 'decimal',
    currency: 'USD',
    minimumFractionDigits: isCurrency ? 2 : 0,
    maximumFractionDigits: isCurrency ? 2 : 0
  }).format(value);
}

interface State {
  scenario: any;
  filteredProjects: any[];
  editedData: { [key: string]: any };
  searchValue: string;
  overrideProjects: any[] | null;
}

export default class InformationalPanelWidget extends React.PureComponent<AllWidgetProps<unknown>, State> {
  constructor(props) {
    super(props);
    this.state = {
      scenario: scenarioData, 
      filteredProjects: scenarioData?.Projects || [], // Ensure it doesn't break if undefined
      editedData: {},
      searchValue: '',
      overrideProjects: null
    };
  }  

  onScenarioChanged = (evt: any) => {
    const newScenario = evt.detail.scenario;
    if (!newScenario || !newScenario.Projects) {
      console.error("❌ Invalid scenario received!", newScenario);
      return;
    }
  
    console.log("InfoPanel => New scenario arrived", newScenario);
    this.setState({
      scenario: newScenario,
      filteredProjects: newScenario.Projects,
      overrideProjects: null,
      editedData: {},
      selectedProject: null // ✅ Reset selected project when scenario changes
    });
  };  

  componentDidMount() {
    console.log("InfoPanel: Adding event listeners...");
    window.addEventListener("scenario-changed", this.onScenarioChanged);
    window.addEventListener("segment-selected", this.handleSegmentSelected);
  
    // ✅ Ensure scenario is properly loaded at startup
    if (!this.state.scenario || !this.state.scenario.Projects) {
      console.warn("⚠️ No scenario data found on mount! Loading default scenario...");
      this.setState({ scenario: scenarioData, filteredProjects: scenarioData?.Projects || [] });
    }
  }  
  
  componentWillUnmount() {
    console.log("InfoPanel: Removing event listeners...");
    window.removeEventListener("scenario-changed", this.onScenarioChanged);
    window.removeEventListener("segment-selected", this.handleSegmentSelected);
  }  

  // Called when a user clicks a segment on the map
  handleSegmentSelected = (event: CustomEvent) => {
    const projId = event.detail.projId;
    console.log("ℹ️ InfoPanel: Received segment-selected event with projId:", projId);
  
    if (!this.state.scenario || !this.state.scenario.Projects) {
      console.error("❌ InfoPanel: No scenario data loaded! Waiting for scenario...");
      return;
    }
  
    const selectedProject = this.state.scenario.Projects.find((p: any) => p.ProjectID === projId);
  
    if (!selectedProject) {
      console.warn("⚠️ InfoPanel: No matching project found for projId:", projId);
      return;
    }
  
    this.setState({ selectedProject }, () => {
      console.log("✅ InfoPanel: Selected project updated successfully!", this.state.selectedProject);
    });
  };   

  handleManualSelection = () => {
    console.log("🛠 Attempting to fetch selected feature...");
  
    // ✅ Ensure we actually have a selected feature
    const selectedFeature = window.__selectedFeature;
    if (!selectedFeature) {
      console.warn("⚠️ No feature selected on the map.");
      return;
    }
  
    console.log("✅ Selected feature FULL attributes:", selectedFeature.attributes);
  
    // ✅ Extract ProjectID or SystemID safely
    let projId = 
      selectedFeature.attributes?.ProjectID ?? 
      selectedFeature.attributes?.projectID ?? 
      selectedFeature.attributes?.SystemID ?? 
      selectedFeature.attributes?.systemID;
  
    // 🛑 If ProjectID/SystemID is missing, log an error with attributes
    if (!projId) {
      console.error("❌ Selected feature has no valid ProjectID or SystemID.", selectedFeature.attributes);
      return;
    }
  
    console.log("✅ Found ProjectID:", projId);
  
    // ✅ Dispatch event to update InfoPanel
    const evt = new CustomEvent("segment-selected", {
      detail: { projId: Number(projId) }
    });
    window.dispatchEvent(evt);
  };  

  // Filter events from RoadSegmentsFilter
  handleFilterUpdated = (evt: any) => {
    const { filteredProjIds } = evt.detail;
    // Now that each project has "ProjectID"
    const newProjects = this.state.scenario.Projects.filter((p: any) =>
      filteredProjIds.includes(p.ProjectID)
    );
    this.setState({ overrideProjects: null, filteredProjects: newProjects });
  };

  handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const searchValue = e.target.value.toLowerCase();
    if (this.state.overrideProjects) {
      const filtered = this.state.overrideProjects.filter((p: any) =>
        p.ProjectID.toString().includes(searchValue)
      );
      this.setState({ searchValue, overrideProjects: filtered });
    } else {
      const filtered = this.state.filteredProjects.filter((p: any) =>
        p.ProjectID.toString().includes(searchValue)
      );
      this.setState({ searchValue, filteredProjects: filtered });
    }
  };

  // Edits to project-level fields
  handleProjectInputChange = (projectID: number, field: string, value: any) => {
    this.setState((prev) => ({
      editedData: {
        ...prev.editedData,
        [projectID]: {
          ...prev.editedData[projectID],
          [field]: value
        }
      }
    }));
  };

  // Edits to treatment-level fields
  handleTreatmentInputChange = (treatmentID: number, field: string, value: any) => {
    this.setState((prev) => ({
      editedData: {
        ...prev.editedData,
        [`treatment-${treatmentID}`]: {
          ...prev.editedData[`treatment-${treatmentID}`],
          [field]: value
        }
      }
    }));
  };

  // Merges this.state.scenario.Projects with user edits
  getUpdatedProjects() {
    return this.state.scenario.Projects.map((p: any) => {
      const edits = this.state.editedData[p.ProjectID] || {};
      return { ...p, ...edits };
    });
  }

  // Merges this.state.scenario.Treatments with user edits
  getUpdatedTreatments() {
    return this.state.scenario.Treatments.map((t: any) => {
      const key = `treatment-${t.TreatmentID}`;
      const edits = this.state.editedData[key] || {};
      return { ...t, ...edits };
    });
  }

  // Example Submit
  submitScenario = async () => {
    try {
      const updated = {
        ...this.state.scenario,
        Projects: this.getUpdatedProjects(),
        Treatments: this.getUpdatedTreatments()
      };      
      const resp = await fetch('https://test.dssanalysis.net/api/scenario/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated)
      });
      if (!resp.ok) {
        console.error('Submit failed');
      } else {
        console.log('Submit successful');
      }
    } catch (err) {
      console.error('Error submitting scenario:', err);
    }
  };

  // Build simple cost summary per year, using "DirectCost" for pavement vs. bridge
  buildCostSummaryRows(treatments: any[]): any[] {
    const years = Array.from(new Set(treatments.map((t: any) => t.Year))).sort();
    const rows = years.map((yr) => {
      const paveDirect = treatments
        .filter((t: any) => t.Year === yr && t.AssetType === 'P')
        .reduce((sum: number, t: any) => sum + (t.DirectCost || 0), 0);
      const brDirect = treatments
        .filter((t: any) => t.Year === yr && t.AssetType === 'B')
        .reduce((sum: number, t: any) => sum + (t.DirectCost || 0), 0);
      return {
        year: yr,
        paveDirect,
        brDirect,
        totalDirect: paveDirect + brDirect
      };
    });
    const totalPave = rows.reduce((sum, r) => sum + r.paveDirect, 0);
    const totalBr = rows.reduce((sum, r) => sum + r.brDirect, 0);
    rows.push({
      year: 'Total',
      paveDirect: totalPave,
      brDirect: totalBr,
      totalDirect: totalPave + totalBr
    });
    return rows;
  }

  render() {
    const { editedData, searchValue, overrideProjects, filteredProjects, selectedProject } = this.state;
    // ✅ If a project is selected, only show that project
    const finalProjectsToShow = selectedProject ? [selectedProject] : overrideProjects ?? filteredProjects;    
  
    return (
      <div style={{ width: '100%', height: '100%', padding: '10px', display: 'flex', flexDirection: 'column' }}>
  
        {/* ✅ Existing Search Bar */}
        {!selectedProject && (
          <input
            type="text"
            placeholder="Search by Project ID..."
            value={searchValue}
            onChange={this.handleSearchChange}
            style={{ width: '100%', padding: '10px', marginBottom: '10px', border: '1px solid #ccc', borderRadius: '5px' }}
          />
        )}

        {selectedProject && (
          <button 
            onClick={() => this.setState({ selectedProject: null })} 
            style={{ padding: '10px', marginBottom: '10px' }}
          >
            Clear Selection
          </button>
        )}
  
        {/* ✅ Project Details List */}
        <div style={{ flex: 1, overflowY: 'auto' }}>
          {finalProjectsToShow.map((project: any) => {
            // Fetch treatments for this project
            const projectTreatments = this.state.scenario.Treatments.filter(
              (t: any) => t.ProjectID === project.ProjectID
            );
  
            // Get edits
            const projEdits = editedData[project.ProjectID] || {};
  
            // Build cost summary
            const costSummaryRows = this.buildCostSummaryRows(projectTreatments);
  
            return (
              <div key={project.ProjectID} style={{ border: '1px solid #000', padding: '15px', marginBottom: '20px', borderRadius: '5px', backgroundColor: '#fff' }}>
                
                {/* Project Identification & Description */}
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '20px' }}>
                  <div style={{ flex: 1, marginRight: '10px' }}>
                    <h4>Project Identification</h4>
                    <div style={{ marginBottom: '8px' }}>
                      <label style={{ fontWeight: 'bold', display: 'block' }}>System ID</label>
                      <input type="text" readOnly style={styles.readOnlyInput} value={project.SystemID} />
                    </div>
                    <div style={{ marginBottom: '8px' }}>
                      <label style={{ fontWeight: 'bold', display: 'block' }}>District</label>
                      <input type="number" readOnly style={styles.readOnlyInput} value={project.District} />
                    </div>
                    <div style={{ marginBottom: '8px' }}>
                      <label style={{ fontWeight: 'bold', display: 'block' }}>County</label>
                      <input type="number" readOnly style={styles.readOnlyInput} value={project.County} />
                    </div>
                    <div style={{ marginBottom: '8px' }}>
                      <label style={{ fontWeight: 'bold', display: 'block' }}>Route</label>
                      <input type="number" readOnly style={styles.readOnlyInput} value={project.Route} />
                    </div>
                  </div>
  
                  <div style={{ flex: 1, marginRight: '10px' }}>
                    <h4>Project Description</h4>
                    <div style={{ marginBottom: '8px' }}>
                      <label style={{ fontWeight: 'bold', display: 'block' }}>User ID</label>
                      <input type="number" style={styles.editableInput} value={projEdits.UserID ?? project.UserID ?? ''} 
                        onChange={(e) => this.handleProjectInputChange(project.ProjectID, 'UserID', e.target.value)} />
                    </div>
                    <div style={{ marginBottom: '8px' }}>
                      <label style={{ fontWeight: 'bold', display: 'block' }}>Start Year</label>
                      <input type="number" style={styles.editableInput} value={projEdits.StartYear ?? project.StartYear ?? ''} 
                        onChange={(e) => this.handleProjectInputChange(project.ProjectID, 'StartYear', e.target.value)} />
                    </div>
                    <div style={{ marginBottom: '8px' }}>
                      <label style={{ fontWeight: 'bold', display: 'block' }}>End Year</label>
                      <input type="number" style={styles.editableInput} value={projEdits.EndYear ?? project.EndYear ?? ''} 
                        onChange={(e) => this.handleProjectInputChange(project.ProjectID, 'EndYear', e.target.value)} />
                    </div>
                  </div>
  
                  <div style={{ flex: 1, marginLeft: '10px' }}>
                    <h4>Notes</h4>
                    <textarea rows={6} style={{ width: '100%', textAlign: 'right' }} placeholder="Enter notes here..." 
                      value={projEdits.Notes ?? project.Notes ?? ''} 
                      onChange={(e) => this.handleProjectInputChange(project.ProjectID, 'Notes', e.target.value)} />
                  </div>
                </div>
  
                {/* Treatments Table */}
                <h4>Treatments</h4>
                <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '20px' }}>
                <thead>
                  <tr style={styles.headerRow}>
                    <th style={styles.cell}>Treatment ID</th>
                    <th style={styles.cell}>Asset</th>
                    <th style={styles.cell}>Route</th>
                    <th style={styles.cell}>Section From</th>
                    <th style={styles.cell}>Section To</th>
                    <th style={styles.cell}>Bridge ID</th>
                    <th style={styles.cell}>MPMS ID</th>  {/* ✅ Ensure this is included */}
                    <th style={styles.cell}>Treatment Type</th>
                    <th style={styles.cell}>Treatment</th>
                    <th style={styles.cell}>Year</th>
                    <th style={styles.cell}>Direct Cost</th>
                    <th style={styles.cell}>Design</th>
                    <th style={styles.cell}>ROW</th>
                    <th style={styles.cell}>Util</th>
                    <th style={styles.cell}>Other</th>
                  </tr>
                </thead>
                <tbody>
                  {projectTreatments.map((t: any) => {
                    const tKey = `treatment-${t.TreatmentID}`;
                    const tEdits = editedData[tKey] || {};
                    return (
                      <tr key={t.TreatmentID}>
                        <td style={styles.cell}>
                          <input type="number" readOnly style={styles.readOnlyInput} value={t.TreatmentID} />
                        </td>
                        <td style={styles.cell}>
                          <input type="text" readOnly style={styles.readOnlyInput} value={t.AssetType ?? ''} />
                        </td>
                        <td style={styles.cell}>
                          <input type="text" readOnly style={styles.readOnlyInput} value={t.Route?.toString() ?? ''} />
                        </td>
                        <td style={styles.cell}>
                          <input type="number" readOnly style={styles.readOnlyInput} value={t.SectionFrom ?? ''} />
                        </td>
                        <td style={styles.cell}>
                          <input type="number" readOnly style={styles.readOnlyInput} value={t.SectionTo ?? ''} />
                        </td>
                        <td style={styles.cell}>
                          <input type="text" readOnly style={styles.readOnlyInput} value={t.BridgeID ?? ''} />
                        </td>
                        <td style={styles.cell}>
                          <input type="text" style={styles.editableInput} value={tEdits.MPMSID ?? t.MPMSID ?? ''} />
                        </td>
                        <td style={styles.cell}>
                          <input type="text" style={styles.editableInput} value={tEdits.TreatmentType ?? t.TreatmentType ?? ''} />
                        </td>
                        <td style={styles.cell}>
                          <input type="text" style={styles.editableInput} value={tEdits.Treatment ?? t.Treatment ?? ''} />
                        </td>
                        <td style={styles.cell}>
                          <input type="number" style={styles.editableInput} value={tEdits.Year ?? t.Year ?? ''} />
                        </td>
                        <td style={styles.cell}>
                          <input type="text" style={styles.editableInput} value={formatNumber(tEdits.DirectCost ?? t.DirectCost, true)} />
                        </td>
                        <td style={styles.cell}>
                          <input type="text" style={styles.editableInput} value={formatNumber(tEdits.DesignCost ?? t.DesignCost, true)} />
                        </td>
                        <td style={styles.cell}>
                          <input type="text" style={styles.editableInput} value={formatNumber(tEdits.ROWCost ?? t.ROWCost, true)} />
                        </td>
                        <td style={styles.cell}>
                          <input type="text" style={styles.editableInput} value={formatNumber(tEdits.UtilCost ?? t.UtilCost, true)} />
                        </td>
                        <td style={styles.cell}>
                          <input type="text" style={styles.editableInput} value={formatNumber(tEdits.OtherCost ?? t.OtherCost, true)} />
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                </table>
              </div>
            );
          })}
        </div>
  
        {/* Submit Button */}
        <button onClick={this.submitScenario} style={{ marginTop: '10px' }}>
          Submit Scenario
        </button>
      </div>
    );
  }
}

const styles: { [key: string]: React.CSSProperties } = {
  headerRow: {
    backgroundColor: '#eee'
  },
  cell: {
    border: '1px solid #ccc',
    padding: '8px',
    textAlign: 'right'
  },
  readOnlyInput: {
    width: '100%',
    backgroundColor: '#eee',
    border: 'none',
    textAlign: 'right'
  },
  editableInput: {
    width: '100%',
    textAlign: 'right'
  }
};