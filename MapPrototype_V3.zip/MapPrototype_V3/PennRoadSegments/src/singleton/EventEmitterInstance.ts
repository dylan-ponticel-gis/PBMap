import { EventEmitter } from 'events';

// Create a shared EventEmitter instance
const eventEmitter = new EventEmitter();

export default eventEmitter;
