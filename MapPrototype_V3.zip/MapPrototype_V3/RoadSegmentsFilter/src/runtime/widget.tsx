/** @jsx jsx */
import { React, AllWidgetProps, jsx } from 'jimu-core';
import { JimuMapViewComponent, JimuMapView } from 'jimu-arcgis';
// Import React Select
import Select from 'react-select';
import FeatureLayer from 'esri/layers/FeatureLayer';
// Import event emitter
import eventEmitter from '../../../PennRoadSegments/src/singleton/EventEmitterInstance'; 

// Import the JSON data
import scenarioData from '../data/scenario.json';

interface OptionType {
  value: string;
  label: string;
}

interface State {
  jimuMapView: JimuMapView | null;
  featureLayer: FeatureLayer | null;
  // We'll track year, assetType, treatment, route
  projectYears: OptionType[];
  assetTypes: OptionType[];
  treatments: OptionType[];
  routes: OptionType[];

  selectedProjectYears: OptionType[];
  selectedAssetTypes: OptionType[];
  selectedTreatments: OptionType[];
  selectedRoutes: OptionType[];
}

export default class RoadSegmentsFilter extends React.PureComponent<AllWidgetProps<unknown>, State> {
  constructor(props: AllWidgetProps<unknown>) {
    super(props);
    this.state = {
      jimuMapView: null,
      featureLayer: null,
      projectYears: [],
      assetTypes: [],
      treatments: [],
      routes: [],
      selectedProjectYears: [],
      selectedAssetTypes: [],
      selectedTreatments: [],
      selectedRoutes: []
    };
  }

  componentDidMount() {
    if (this.state.jimuMapView) {
      this.initialize();
    }
    window.addEventListener("scenario-changed", this.onScenarioChanged);
  }

  componentWillUnmount() {
    window.removeEventListener("scenario-changed", this.onScenarioChanged);
  }


  componentDidUpdate(prevProps: AllWidgetProps<unknown>, prevState: State) {
    if (this.state.jimuMapView !== prevState.jimuMapView && this.state.jimuMapView) {
      this.initialize();
    }
  }

  initialize = () => {
    const checkLayer = () => {
      const map = this.state.jimuMapView?.view.map;
      if (!map) {
        console.warn('Map is not available yet.');
        return;
      }
      const featureLayer = map.findLayerById('ScenarioTreatmentsLayer') as FeatureLayer;
      if (featureLayer) {
        this.setState({ featureLayer }, () => {
          this.getUniqueValues();
        });
      } else {
        setTimeout(checkLayer, 500);
      }
    };
    checkLayer();
  }

  onScenarioChanged = (evt: any) => {
    const newScenario = evt.detail.scenario;
    if (!newScenario) return;

    console.log("FilteringWidget: New scenario detected, reloading filters.");

    // Reset selected filters
    this.setState({
      selectedProjectYears: [],
      selectedAssetTypes: [],
      selectedTreatments: [],
      selectedRoutes: []
    }, () => {
      // Recompute unique filter values based on the new scenario
      this.getUniqueValues(newScenario);
    });
  };

  // Now we have new fields: t.Year, t.AssetType, t.Treatment, t.Route
  getUniqueValues = (scenario = scenarioData) => {  // Default to scenarioData but allow override
    const treatments = scenario.Treatments;

    const yearSet = new Set<string>();
    const assetTypeSet = new Set<string>();
    const treatmentSet = new Set<string>();
    const routeSet = new Set<string>();

    treatments.forEach((t: any) => {
      if (t.Year != null) {
        yearSet.add(String(t.Year));
      }
      if (t.AssetType) {
        assetTypeSet.add(t.AssetType.trim());
      }
      if (t.Treatment) {
        treatmentSet.add(t.Treatment.trim());
      }
      if (t.Route != null) {
        routeSet.add(String(t.Route));
      }
    });

    const projectYears = Array.from(yearSet).sort().map((y) => ({ value: y, label: y }));
    const assetTypes = Array.from(assetTypeSet).sort().map((at) => ({ value: at, label: at }));
    const treatmentsOptions = Array.from(treatmentSet).sort().map((tr) => ({ value: tr, label: tr }));
    const routes = Array.from(routeSet).sort().map((r) => ({ value: r, label: r }));

    this.setState({
      projectYears,
      assetTypes,
      treatments: treatmentsOptions,  // ✅ Now updating correctly!
      routes
    });
  };

  onActiveViewChange = (jimuMapView: JimuMapView) => {
    if (jimuMapView) {
      this.setState({ jimuMapView }, () => {
        console.log('MapView updated');
        this.initialize();
      });
    } else {
      this.setState({ jimuMapView: null, featureLayer: null });
    }
  };

  handleFilterChange = (stateKey: keyof State, selectedOptions: OptionType[]) => {
    console.log(`handleFilterChange => stateKey: ${stateKey}`, selectedOptions);
    this.setState({ [stateKey]: selectedOptions } as Pick<State, keyof State>, () => {
      this.applyFilter();
    });
  };

  isFilterActive = (filterKey: keyof State): boolean => {
    const values = this.state[filterKey] as OptionType[];
    return values.length > 0;
  };

  clearAllFilters = () => {
    this.setState({
      selectedProjectYears: [],
      selectedAssetTypes: [],
      selectedTreatments: [],
      selectedRoutes: []
    }, this.applyFilter);
  };

  applyFilter = () => {
    const {
      featureLayer,
      selectedProjectYears,
      selectedAssetTypes,
      selectedTreatments,
      selectedRoutes
    } = this.state;

    if (!featureLayer) return;

    const whereClauses: string[] = [];

    // Year Filter
    if (selectedProjectYears.length > 0) {
      const yearVals = selectedProjectYears.map(opt => +opt.value);
      whereClauses.push(`Year IN (${yearVals.join(',')})`);
      
      window.dispatchEvent(new CustomEvent("symbologyUpdate", {
        detail: { useCostBasedSymbology: true }
      }));
    } else {
      window.dispatchEvent(new CustomEvent("symbologyUpdate", {
        detail: { useCostBasedSymbology: false }
      }));
    }

    // Asset Type Filter
    if (selectedAssetTypes.length > 0) {
      const vals = selectedAssetTypes.map(opt => `'${opt.value}'`);
      whereClauses.push(`AssetType IN (${vals.join(',')})`);
    }

    // ✅ Corrected: Treatment Filter (Using "Treatment" instead of "TreatmentName")
    if (selectedTreatments.length > 0) {
      const vals = selectedTreatments.map(opt => `'${opt.value.replace(/'/g, "''")}'`);
      whereClauses.push(`Treatment IN (${vals.join(',')})`);
    }

    // Route Filter
    if (selectedRoutes.length > 0) {
      const vals = selectedRoutes.map(opt => +opt.value);
      whereClauses.push(`Route IN (${vals.join(',')})`);
    }

    const definitionExpression = whereClauses.join(' AND ');
    featureLayer.definitionExpression = definitionExpression;

    // Find projects that match the filter
    const filteredProjIds = this.getFilteredProjectIds(
      selectedProjectYears,
      selectedAssetTypes,
      selectedTreatments,
      selectedRoutes
    );

    // Emit an event for the Info Panel
    const evt = new CustomEvent('filter-updated', { detail: { filteredProjIds } });
    window.dispatchEvent(evt);

    console.log("Updated Definition Expression:", definitionExpression);
};

  // figure out which projects pass the user's filter
  getFilteredProjectIds(
    selectedProjectYears: OptionType[],
    selectedAssetTypes: OptionType[],
    selectedTreatments: OptionType[],
    selectedRoutes: OptionType[]
  ) {
    // Turn filter sets into arrays
    const yearNums = selectedProjectYears.map(o => +o.value);
    const assetStrings = selectedAssetTypes.map(o => o.value);
    const treatmentStrings = selectedTreatments.map(o => o.value);
    const routeNums = selectedRoutes.map(o => +o.value);

    const filteredIds = new Set<number>();

    scenarioData.Projects.forEach((proj: any) => {
      // Find treatments for this project
      const tList = scenarioData.Treatments.filter((t: any) => t.ProjectID === proj.ProjectID);
      const passes = tList.some((t: any) => {
        const yearOk = !yearNums.length || yearNums.includes(t.Year);
        const assetOk = !assetStrings.length || assetStrings.includes(t.AssetType);
        const treatOk = !treatmentStrings.length || treatmentStrings.includes(t.Treatment);
        const routeOk = !routeNums.length || routeNums.includes(t.Route);
        return (yearOk && assetOk && treatOk && routeOk);
      });
      if (passes) filteredIds.add(proj.ProjectID);
    });

    return Array.from(filteredIds);
  }

  render() {
    const {
      projectYears,
      assetTypes,
      treatments,
      routes,
      selectedProjectYears,
      selectedAssetTypes,
      selectedTreatments,
      selectedRoutes
    } = this.state;

    return (
      <div
        className="widget-road-segments-filter"
        style={{
          display: 'flex',
          flexDirection: 'row',
          alignItems: 'flex-start',
          justifyContent: 'space-around',
          padding: '3px',
          backgroundColor: '#f5f5f5',
          borderRadius: '8px',
          flexWrap: 'wrap'
        }}
      >
        {/* Year Filter */}
        <div style={{ margin: '10px', minWidth: '200px' }}>
          <label
            htmlFor="projectYear"
            style={{
              display: 'block',
              marginBottom: '2px',
              fontWeight: this.isFilterActive('selectedProjectYears') ? 'bold' : 'normal',
              color: this.isFilterActive('selectedProjectYears') ? 'blue' : 'inherit'
            }}
          >
            Year
          </label>
          <Select
            id="projectYear"
            isMulti
            options={projectYears}
            value={selectedProjectYears}
            onChange={(opts) => this.handleFilterChange('selectedProjectYears', opts as OptionType[])}
            placeholder="Select Year(s)"
            styles={{
              control: (provided) => ({ ...provided, minHeight: '35px' }),
              multiValue: (provided) => ({ ...provided, backgroundColor: 'lightblue' })
            }}
          />
        </div>

        {/* Asset Type Filter */}
        <div style={{ margin: '10px', minWidth: '200px' }}>
          <label
            htmlFor="assetType"
            style={{
              display: 'block',
              marginBottom: '5px',
              fontWeight: this.isFilterActive('selectedAssetTypes') ? 'bold' : 'normal',
              color: this.isFilterActive('selectedAssetTypes') ? 'blue' : 'inherit'
            }}
          >
            Asset Type
          </label>
          <Select
            id="assetType"
            isMulti
            options={assetTypes}
            value={selectedAssetTypes}
            onChange={(opts) => this.handleFilterChange('selectedAssetTypes', opts as OptionType[])}
            placeholder="Select Asset(s)"
            styles={{
              control: (provided) => ({ ...provided, minHeight: '35px' }),
              multiValue: (provided) => ({ ...provided, backgroundColor: 'lightblue' })
            }}
          />
        </div>

        {/* Treatment Filter */}
        <div style={{ margin: '10px', minWidth: '250px' }}>
          <label
            htmlFor="treatment"
            style={{
              display: 'block',
              marginBottom: '5px',
              fontWeight: this.isFilterActive('selectedTreatments') ? 'bold' : 'normal',
              color: this.isFilterActive('selectedTreatments') ? 'blue' : 'inherit'
            }}
          >
            Treatment
          </label>
          <Select
            id="treatment"
            isMulti
            options={treatments}
            value={selectedTreatments}
            onChange={(opts) => this.handleFilterChange('selectedTreatments', opts as OptionType[])}
            placeholder="Select Treatment(s)"
            styles={{
              control: (provided) => ({ ...provided, minHeight: '35px' }),
              multiValue: (provided) => ({ ...provided, backgroundColor: 'lightblue' })
            }}
          />
        </div>

        {/* Route Filter */}
        <div style={{ margin: '10px', minWidth: '200px' }}>
          <label
            htmlFor="route"
            style={{
              display: 'block',
              marginBottom: '5px',
              fontWeight: this.isFilterActive('selectedRoutes') ? 'bold' : 'normal',
              color: this.isFilterActive('selectedRoutes') ? 'blue' : 'inherit'
            }}
          >
            Route
          </label>
          <Select
            id="route"
            isMulti
            options={routes}
            value={selectedRoutes}
            onChange={(opts) => this.handleFilterChange('selectedRoutes', opts as OptionType[])}
            placeholder="Select Route(s)"
            styles={{
              control: (provided) => ({ ...provided, minHeight: '35px' }),
              multiValue: (provided) => ({ ...provided, backgroundColor: 'lightblue' })
            }}
          />
        </div>

        {/* Clear All Filters Button */}
        <div style={{ margin: '10px', alignSelf: 'center' }}>
          <button onClick={this.clearAllFilters} style={{ padding: '5px 10px' }}>
            Clear All Filters
          </button>
        </div>

        {/* Include the map view component */}
        {this.props.useMapWidgetIds?.length ? (
          <div style={{ display: 'none' }}>
            <JimuMapViewComponent
              useMapWidgetId={this.props.useMapWidgetIds[0]}
              onActiveViewChange={this.onActiveViewChange}
            />
          </div>
        ) : null}
      </div>
    );
  }
}
