/** @jsx jsx */
import { React, AllWidgetProps, jsx } from 'jimu-core';
import { JimuMapViewComponent, JimuMapView } from 'jimu-arcgis';
import eventEmitter from '../singleton/EventEmitterInstance';
import FeatureLayer from 'esri/layers/FeatureLayer';
import Graphic from 'esri/Graphic';
import Polyline from 'esri/geometry/Polyline';
import * as projection from 'esri/geometry/projection';
import * as geometryEngine from 'esri/geometry/geometryEngine';

// Load a default scenario JSON as fallback
import defaultScenarioData from '../data/scenario.json';

console.log("PennRoadSegments: eventEmitter path =", require.resolve('../singleton/EventEmitterInstance'));

// Segment Treatment Styles from configLayerStyles.js script
const segmentTreatmentStyles = {
  "Bituminous Overlay": {
    "color": "rgba(107,14,62,1)"
  },
  "Bridge Replacement": {
    "color": "rgba(139,14,94,1)"
  },
  "CommittedTreatmentType": {
    "color": "rgba(153,98,156,1)"
  },
  "Culvert Rehab (Other)": {
    "color": "rgba(151,165,226,1)"
  },
  "Culvert Replacement (Box/Frame/Arch)": {
    "color": "rgba(151,165,226,1)"
  },
  "Culvert Replacement (Other)": {
    "color": "rgba(151,165,226,1)"
  },
  "Culvert Replacement (Pipe)": {
    "color": "rgba(151,165,226,1)"
  },
  "Deck Replacement": {
    "color": "rgba(140,206,248,1)"
  },
  "Epoxy/Joint Glands/Coatings": {
    "color": "rgba(132,233,239,1)"
  },
  "H1": {
    "color": "rgba(34,234,34,1)"
  },
  "H10": {
    "color": "rgba(34,234,34,1)"
  },
  "H11": {
    "color": "rgba(34,234,34,1)"
  },
  "H12": {
    "color": "rgba(34,234,34,1)"
  },
  "H13": {
    "color": "rgba(34,234,34,1)"
  },
  "H14": {
    "color": "rgba(34,234,34,1)"
  },
  "H15": {
    "color": "rgba(34,234,34,1)"
  },
  "H16": {
    "color": "rgba(34,234,34,1)"
  },
  "H16+H4": {
    "color": "rgba(34,234,34,1)"
  },
  "H17": {
    "color": "rgba(34,234,34,1)"
  },
  "H18": {
    "color": "rgba(34,234,34,1)"
  },
  "H19": {
    "color": "rgba(34,234,34,1)"
  },
  "H2": {
    "color": "rgba(34,234,34,1)"
  },
  "H20": {
    "color": "rgba(34,234,34,1)"
  },
  "H21": {
    "color": "rgba(34,234,34,1)"
  },
  "H22": {
    "color": "rgba(34,234,34,1)"
  },
  "H23": {
    "color": "rgba(34,234,34,1)"
  },
  "H3": {
    "color": "rgba(34,234,34,1)"
  },
  "H4": {
    "color": "rgba(34,234,34,1)"
  },
  "H5": {
    "color": "rgba(34,234,34,1)"
  },
  "H6": {
    "color": "rgba(34,234,34,1)"
  },
  "H7": {
    "color": "rgba(34,234,34,1)"
  },
  "H8": {
    "color": "rgba(34,234,34,1)"
  },
  "H9": {
    "color": "rgba(34,234,34,1)"
  },
  "J1": {
    "color": "rgba(207,251,114,1)"
  },
  "J10": {
    "color": "rgba(207,251,114,1)"
  },
  "J11": {
    "color": "rgba(207,251,114,1)"
  },
  "J11+J9": {
    "color": "rgba(207,251,114,1)"
  },
  "J12": {
    "color": "rgba(207,251,114,1)"
  },
  "J13": {
    "color": "rgba(207,251,114,1)"
  },
  "J14": {
    "color": "rgba(207,251,114,1)"
  },
  "J14+J1": {
    "color": "rgba(207,251,114,1)"
  },
  "J14+J9": {
    "color": "rgba(207,251,114,1)"
  },
  "J15": {
    "color": "rgba(207,251,114,1)"
  },
  "J16": {
    "color": "rgba(207,251,114,1)"
  },
  "J17": {
    "color": "rgba(207,251,114,1)"
  },
  "J17+J12": {
    "color": "rgba(207,251,114,1)"
  },
  "J17+J9": {
    "color": "rgba(207,251,114,1)"
  },
  "J18": {
    "color": "rgba(207,251,114,1)"
  },
  "J19": {
    "color": "rgba(207,251,114,1)"
  },
  "J2": {
    "color": "rgba(207,251,114,1)"
  },
  "J20": {
    "color": "rgba(207,251,114,1)"
  },
  "J21": {
    "color": "rgba(207,251,114,1)"
  },
  "J21+J12": {
    "color": "rgba(207,251,114,1)"
  },
  "J21+J15": {
    "color": "rgba(207,251,114,1)"
  },
  "J21+J7": {
    "color": "rgba(207,251,114,1)"
  },
  "J21+J8": {
    "color": "rgba(207,251,114,1)"
  },
  "J21+J9": {
    "color": "rgba(207,251,114,1)"
  },
  "J22": {
    "color": "rgba(207,251,114,1)"
  },
  "J22+J12": {
    "color": "rgba(207,251,114,1)"
  },
  "J22+J8": {
    "color": "rgba(207,251,114,1)"
  },
  "J22+J9": {
    "color": "rgba(207,251,114,1)"
  },
  "J23": {
    "color": "rgba(207,251,114,1)"
  },
  "J23+J12": {
    "color": "rgba(207,251,114,1)"
  },
  "J23+J9": {
    "color": "rgba(207,251,114,1)"
  },
  "J24": {
    "color": "rgba(207,251,114,1)"
  },
  "J24+J12": {
    "color": "rgba(207,251,114,1)"
  },
  "J24+J9": {
    "color": "rgba(207,251,114,1)"
  },
  "J25": {
    "color": "rgba(207,251,114,1)"
  },
  "J25+J12": {
    "color": "rgba(207,251,114,1)"
  },
  "J25+J15": {
    "color": "rgba(207,251,114,1)"
  },
  "J25+J4": {
    "color": "rgba(207,251,114,1)"
  },
  "J25+J7": {
    "color": "rgba(207,251,114,1)"
  },
  "J25+J8": {
    "color": "rgba(207,251,114,1)"
  },
  "J25+J9": {
    "color": "rgba(207,251,114,1)"
  },
  "J26": {
    "color": "rgba(207,251,114,1)"
  },
  "J26+J12": {
    "color": "rgba(207,251,114,1)"
  },
  "J26+J7": {
    "color": "rgba(207,251,114,1)"
  },
  "J26+J8": {
    "color": "rgba(207,251,114,1)"
  },
  "J26+J9": {
    "color": "rgba(207,251,114,1)"
  },
  "J27": {
    "color": "rgba(207,251,114,1)"
  },
  "J3": {
    "color": "rgba(207,251,114,1)"
  },
  "J4": {
    "color": "rgba(207,251,114,1)"
  },
  "J5": {
    "color": "rgba(207,251,114,1)"
  },
  "J6": {
    "color": "rgba(207,251,114,1)"
  },
  "J7": {
    "color": "rgba(207,251,114,1)"
  },
  "J8": {
    "color": "rgba(207,251,114,1)"
  },
  "J9": {
    "color": "rgba(207,251,114,1)"
  },
  "Latex/Joints/Coatings": {
    "color": "rgba(255,255,0,1)"
  },
  "No Treatment": {
    "color": "rgba(156,156,156,1)"
  },
  "Overlay": {
    "color": "rgba(251,217,94,1)"
  },
  "Painting (Full)": {
    "color": "rgba(240,126,45,1)"
  },
  "Painting (Joint/Spot/Zone)": {
    "color": "rgba(240,126,45,1)"
  },
  "Substructure Rehab": {
    "color": "rgba(230,0,0,1)"
  },
  "Superstructure Rep/Rehab": {
    "color": "rgba(230,0,169,1)"
  },
  "Structural Overlay/Joints/Coatings": {
    "color": "rgba(230,127,220,1)"
  },
};

interface State {
  jimuMapView: JimuMapView | null;
  useCostBasedSymbology: boolean;
  scenarioData: any; // current scenario in state
}

/** @jsx jsx */
import { React, AllWidgetProps, jsx } from 'jimu-core';
import { JimuMapViewComponent, JimuMapView } from 'jimu-arcgis';
import eventEmitter from '../singleton/EventEmitterInstance';
import FeatureLayer from 'esri/layers/FeatureLayer';
import Graphic from 'esri/Graphic';
import Polyline from 'esri/geometry/Polyline';
import * as projection from 'esri/geometry/projection';
import * as geometryEngine from 'esri/geometry/geometryEngine';

// Start with default scenario
import defaultScenarioData from '../data/scenario.json';

// segmentTreatmentStyles is presumably your style config
// import or define segmentTreatmentStyles as needed

interface State {
  jimuMapView: JimuMapView | null;
  useCostBasedSymbology: boolean;
  scenarioData: any; 
}

export default class PennRoadSegments extends React.PureComponent<AllWidgetProps<unknown>, State> {
  featureLayer: FeatureLayer;
  fileInputRef: React.RefObject<HTMLInputElement>;

  constructor(props: AllWidgetProps<unknown>) {
    super(props);

    this.state = {
      jimuMapView: null,
      useCostBasedSymbology: false,
      scenarioData: defaultScenarioData
    };

    this.fileInputRef = React.createRef();

    // Define layer schema
    // 🛠 Ensure FeatureLayer has correct fields before adding graphics
    this.featureLayer = new FeatureLayer({
      title: 'Scenario Treatments',
      id: 'ScenarioTreatmentsLayer',
      visible: true,
      objectIdField: 'OBJECTID',
      geometryType: 'polyline',
      spatialReference: { wkid: 102100 },
      fields: [
        { name: 'OBJECTID', type: 'oid' },
        { name: 'ProjectID', type: 'integer' },  // ✅ Ensure this is defined
        { name: 'SystemID', type: 'integer' },   // ✅ Ensure this is defined
        { name: 'TreatmentID', type: 'integer' },
        { name: 'AssetType', type: 'string' },
        { name: 'Route', type: 'integer' },
        { name: 'SectionFrom', type: 'integer' },
        { name: 'SectionTo', type: 'integer' },
        { name: 'BridgeID', type: 'string' },
        { name: 'TreatmentType', type: 'string' },
        { name: 'Treatment', type: 'string' },
        { name: 'Year', type: 'integer' },
        { name: 'DirectCost', type: 'double' },
        { name: 'DesignCost', type: 'double' },
        { name: 'ROWCost', type: 'double' },
        { name: 'UtilCost', type: 'double' },
        { name: 'OtherCost', type: 'double' }
      ],
      popupTemplate: {
        title: 'Treatment: {Treatment}',
        content: [
          {
            type: 'fields',
            fieldInfos: [
              { fieldName: 'ProjectID', label: 'Project ID' },  // ✅ Ensure included
              { fieldName: 'SystemID', label: 'System ID' },    // ✅ Ensure included
              { fieldName: 'TreatmentID', label: 'Treatment ID' },
              { fieldName: 'AssetType', label: 'Asset Type' },
              { fieldName: 'Route', label: 'Route' },
              { fieldName: 'SectionFrom', label: 'Section From' },
              { fieldName: 'SectionTo', label: 'Section To' },
              { fieldName: 'BridgeID', label: 'Bridge ID' },
              { fieldName: 'TreatmentType', label: 'Treatment Type' },
              { fieldName: 'Year', label: 'Year' },
              { fieldName: 'DirectCost', label: 'Direct Cost' },
              { fieldName: 'DesignCost', label: 'Design Cost' },
              { fieldName: 'ROWCost', label: 'ROW Cost' },
              { fieldName: 'UtilCost', label: 'Util Cost' },
              { fieldName: 'OtherCost', label: 'Other Cost' }
            ]
          }
        ]
      }
    });

    this.featureLayer.outFields = ["*"];
    this.featureLayer.popupEnabled = true;
    this.featureLayer.elevationInfo = {
      mode: "on-the-ground"
    };

    this.featureLayer.renderer = this.getRenderer();
  }

  componentDidMount() {
    window.addEventListener('symbologyUpdate', this.handleSymbologyUpdate);
    window.addEventListener('scenario-changed', this.handleScenarioChanged);

    // If JimuMapView was already defined
    if (this.state.jimuMapView) {
      this.setupPopupSelection(this.state.jimuMapView.view);
      this.loadDataFromScenario(this.state.scenarioData);
    }
  }

  componentWillUnmount() {
    window.removeEventListener('symbologyUpdate', this.handleSymbologyUpdate);
    window.removeEventListener('scenario-changed', this.handleScenarioChanged);
  }

  componentDidUpdate(prevProps: AllWidgetProps<unknown>, prevState: State) {
    // If the map view changed, we re-load
    if (this.state.jimuMapView !== prevState.jimuMapView && this.state.jimuMapView) {
      this.setupPopupSelection(this.state.jimuMapView.view);
      this.loadDataFromScenario(this.state.scenarioData);
    }

    // If symbology toggled
    if (
      this.state.useCostBasedSymbology !== prevState.useCostBasedSymbology &&
      this.featureLayer
    ) {
      this.featureLayer.renderer = this.getRenderer();
      this.featureLayer.refresh();
    }
  }

  handleSymbologyUpdate = (evt: any) => {
    this.setState({ useCostBasedSymbology: evt.detail.useCostBasedSymbology });
  };

  handleScenarioChanged = (evt: any) => {
    const newScenario = evt.detail.scenario; 
    if (!newScenario) return;

    console.log('PennRoadSegments => scenario-changed. Reloading map data...');
    this.setState({ scenarioData: newScenario }, () => {
      this.loadDataFromScenario(newScenario);
    });
  };

  activeViewChangeHandler = (jmv: JimuMapView) => {
    // Remove old layer
    if (this.state.jimuMapView) {
      this.state.jimuMapView.view.map.remove(this.featureLayer);
    }

    // Set new map view
    if (jmv) {
      this.setState({ jimuMapView: jmv }, () => {
        // Re-load
        this.loadDataFromScenario(this.state.scenarioData);
      });
    }
  };

  // Temporary "Import" button for user to load scenario
  renderImportControls() {
    const onImportClick = () => {
      if (this.fileInputRef.current) {
        this.fileInputRef.current.value = '';
        this.fileInputRef.current.click();
      }
    };

    const onFileSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      try {
        const text = await file.text();
        const parsed = JSON.parse(text);
        console.log('User imported scenario =>', parsed);

        // Fire the scenario-changed event
        const evt = new CustomEvent('scenario-changed', {
          detail: { scenario: parsed }
        });
        window.dispatchEvent(evt);

        // We also set local state, just to be safe
        this.setState({ scenarioData: parsed }, () => {
          this.loadDataFromScenario(parsed);
        });
      } catch (err) {
        console.error('Error reading scenario file:', err);
      }
    };

    return (
      <div style={{ marginBottom: 8 }}>
        <button onClick={onImportClick} style={{ padding: '5px 10px' }}>
          Import Scenario
        </button>
        <input
          type="file"
          accept=".json"
          ref={this.fileInputRef}
          style={{ display: 'none' }}
          onChange={onFileSelected}
        />
      </div>
    );
  }

  getRenderer() {
    // Keep your normal logic for cost-based vs. year-based
    if (this.state.useCostBasedSymbology) {
      return {
        type: 'class-breaks',
        field: 'DirectCost',
        classBreakInfos: [
          {
            minValue: 0,
            maxValue: 50000,
            symbol: { type: 'simple-line', color: [34, 139, 34], width: 3 },
            label: '< $50K'
          },
          {
            minValue: 50001,
            maxValue: 200000,
            symbol: { type: 'simple-line', color: [144, 238, 144], width: 3 },
            label: '$50K - $200K'
          },
          {
            minValue: 200001,
            maxValue: Infinity,
            symbol: { type: 'simple-line', color: [178, 34, 34], width: 3 },
            label: '> $200K'
          }
        ]
      };
    } else {
      return {
        type: 'unique-value',
        field: 'Year',
        uniqueValueInfos: [
          {
            value: 2026,
            symbol: { type: 'simple-line', color: [70, 130, 180], width: 3 },
            label: '2026'
          },
          {
            value: 2027,
            symbol: { type: 'simple-line', color: [30, 144, 255], width: 3 },
            label: '2027'
          },
          {
            value: 2029,
            symbol: { type: 'simple-line', color: [0, 0, 139], width: 3 },
            label: '2029'
          }
        ],
        defaultSymbol: { type: 'simple-line', color: [128, 128, 128], width: 2 }
      };
    }
  }

  selectedFeature: __esri.Graphic | null = null; // ✅ Store last clicked feature

  setupPopupSelection(view: __esri.MapView | __esri.SceneView) {
    if (!view || view.type === "3d") return;
    const mapView = view as __esri.MapView;
  
    mapView.on("click", async (event) => {
      try {
        console.log("🖱 Click event fired at:", event.mapPoint);
        const response = await mapView.hitTest(event);
        console.log("🧐 HitTest Response:", response);
  
        if (!response.results.length) {
          console.warn("⚠️ No features detected at click location.");
          return;
        }
  
        // Find the feature from the correct layer
        const clickedFeature = response.results.find(
          (result) => result.graphic.layer === this.featureLayer
        )?.graphic;
  
        if (!clickedFeature) {
          console.warn("⚠️ No valid feature clicked.");
          return;
        }
  
        // 🔥 Log attributes
        console.log("🖱 Clicked feature FULL attributes:", clickedFeature.attributes);
  
        let projId =
          clickedFeature.attributes?.ProjectID ??
          clickedFeature.attributes?.projectID ??
          clickedFeature.attributes?.SystemID ??
          clickedFeature.attributes?.systemID;
  
        if (!projId) {
          console.warn("❌ Clicked feature has no valid ProjectID or SystemID.");
          return;
        }
  
        console.log("✅ Found ProjectID:", projId);
  
        const evt = new CustomEvent("segment-selected", {
          detail: { projId: Number(projId) }
        });
        window.dispatchEvent(evt);
      } catch (err) {
        console.error("❌ Error handling segment click:", err);
      }
    });
  }  
  
  // ✅ Expose a method to get the selected feature
  getSelectedFeature() {
    console.log("📌 getSelectedFeature() called.");
    if (!this.selectedFeature) {
      console.warn("⚠️ No feature is currently selected.");
    } else {
      console.log("✅ Selected feature attributes:", this.selectedFeature.attributes);
    }
    return this.selectedFeature;
  }   

  // Main function to load the scenario data
  loadDataFromScenario(scenario: any) {
    if (!this.state.jimuMapView) return;
    const view = this.state.jimuMapView.view;
    if (!view) return;
    
    // Remove the old layer if it exists
    const map = view.map;
    const existingLayer = map.findLayerById(this.featureLayer.id);
    if (existingLayer) {
      map.remove(existingLayer);
    }
  
    projection.load().then(() => {
      this._loadTreatments(view, scenario);
    });
  }

  // Fetch PennDOT geometry & build Graphics
  async _loadTreatments(view: __esri.MapView, scenario: any) {
    try {
        view.map.basemap = 'gray-vector';
        const { Projects, Treatments } = scenario;
        if (!Projects || !Treatments) {
            console.warn('⚠️ Scenario lacks Projects or Treatments array');
            return;
        }

        const graphics: __esri.Graphic[] = [];
        let objectIdCounter = 1;

        const geometriesToProject: { geometry: __esri.Polyline; treatment: any; project: any }[] = [];

        for (const t of Treatments) {
            const foundProject = Projects.find((proj: any) => proj.ProjectID === t.ProjectID);
            if (!foundProject) {
                console.warn(`⚠️ No matching project for TreatmentID=${t.TreatmentID}, ProjectID=${t.ProjectID}`);
                continue;
            }

            if (!foundProject.ProjectID || !foundProject.SystemID) {
                console.warn(`⚠️ Skipping project due to missing ProjectID/SystemID:`, foundProject);
                continue;
            }

            if (foundProject.County == null || t.Route == null) continue;

            const whereClause = `(
                CTY_CODE='${foundProject.County.toString().padStart(2, '0')}'
                AND ST_RT_NO='${t.Route.toString().padStart(4, '0')}'
                AND SEG_NO >= '${t.SectionFrom.toString().padStart(4, '0')}'
                AND SEG_NO <= '${t.SectionTo.toString().padStart(4, '0')}'
            )`;

            console.log(`🔍 Querying for Treatment ${t.TreatmentID}:`, whereClause);

            // Fetch data from API
            const params = {
                where: whereClause,
                returnGeometry: true,
                outFields: 'ST_RT_NO,CTY_CODE,DISTRICT_NO,SEG_NO',
                outSR: '4326',
                f: 'json'
            };

            const resp = await fetch(
                'https://gis.penndot.gov/arcgis/rest/services/opendata/roadwaysegments/MapServer/0/query',
                {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: new URLSearchParams(params)
                }
            );

            const data = await resp.json();
            if (data.error) {
                console.error('❌ API Error:', data.error);
                continue;
            }

            if (!data.features || data.features.length === 0) {
                console.warn(`⚠️ No matching features found for Treatment ${t.TreatmentID}`);
                continue;
            }

            data.features.forEach((feature: any) => {
                if (!feature.geometry) {
                    console.warn(`⚠️ Skipping feature due to missing geometry:`, feature);
                    return;
                }

                geometriesToProject.push({
                    geometry: new Polyline(feature.geometry),
                    treatment: t,
                    project: foundProject
                });
            });
        }

        if (geometriesToProject.length === 0) {
            console.warn("⚠️ No valid geometries found for projection.");
            return;
        }

        await projection.load();
        const projected = projection.project(
            geometriesToProject.map((g) => g.geometry),
            view.spatialReference
        ) as __esri.Polyline[];

        const grouped: { [key: string]: __esri.Polyline[] } = {};
        projected.forEach((geom, idx) => {
            if (!geom) {
                console.warn(`⚠️ Skipping projected geometry at index ${idx} (undefined)`);
                return;
            }

            const t = geometriesToProject[idx].treatment;
            const key = `${t.ProjectID}_${t.TreatmentID}`;
            grouped[key] = grouped[key] || [];
            grouped[key].push(geom);
        });

        for (const key in grouped) {
            const [projIDStr, treatIDStr] = key.split('_');
            const projID = parseInt(projIDStr, 10);
            const treatID = parseInt(treatIDStr, 10);

            const unioned = geometryEngine.union(grouped[key]) as __esri.Polyline;
            const found = geometriesToProject.find(
                (g) => g.treatment.ProjectID === projID && g.treatment.TreatmentID === treatID
            );

            if (!found) continue;

            const t = found.treatment;
            const p = found.project;

            if (!p || !t) {
                console.warn(`⚠️ Skipping Treatment ${t?.TreatmentID} due to missing project or treatment data`);
                continue;
            }

            const atts = {
                OBJECTID: objectIdCounter++,
                ProjectID: p.ProjectID, // ✅ Use the actual ProjectID
                SystemID: p.SystemID, // ✅ Use the actual SystemID
                TreatmentID: t.TreatmentID,
                AssetType: t.AssetType,
                Route: t.Route,
                SectionFrom: t.SectionFrom,
                SectionTo: t.SectionTo,
                BridgeID: t.BridgeID || '',
                TreatmentType: t.TreatmentType,
                Treatment: t.Treatment,
                Year: t.Year,
                DirectCost: t.DirectCost,
                DesignCost: t.DesignCost,
                ROWCost: t.ROWCost,
                UtilCost: t.UtilCost,
                OtherCost: t.OtherCost
            };

            console.log("🛠 Adding graphic with attributes:", atts);

            graphics.push(
                new Graphic({
                    geometry: unioned,
                    attributes: atts,
                    symbol: {
                        type: 'simple-line',
                        color: segmentTreatmentStyles[t.Treatment]?.color || [0, 0, 0, 1],
                        width: 3
                    }
                })
            );
        }

        // Filter out invalid graphics before applying edits
        const validGraphics = graphics.filter(g => g.geometry && g.attributes && g.attributes.ProjectID);
        if (!validGraphics.length) {
            console.error("❌ No valid graphics to add to FeatureLayer!");
            return;
        }

        if (view.map.findLayerById(this.featureLayer.id)) {
            view.map.remove(this.featureLayer);
        }

        this.featureLayer.source = [];

        this.featureLayer.applyEdits({
            addFeatures: validGraphics
        }).then((result) => {
            console.log(`✅ Successfully added ${result.addFeatureResults.length} graphics.`);
        }).catch((error) => {
            console.error("❌ Error applying edits:", error);
        });

        view.map.add(this.featureLayer);

        if (graphics.length > 0) {
            let fullExtent = graphics[0].geometry.extent.clone();
            graphics.forEach(g => {
                fullExtent = fullExtent.union(g.geometry.extent);
            });

            const bufferFactor = 0.30;
            const expandedExtent = fullExtent.expand(1 + bufferFactor);

            view.goTo({ target: expandedExtent });
        }
    } catch (err) {
        console.error('❌ Error loading data:', err);
    }
  }

  render() {
    return (
      <div style={{ height: '100%', width: '100%', overflow: 'auto' }}>
        {this.renderImportControls()}

        {this.props.useMapWidgetIds && this.props.useMapWidgetIds.length > 0 ? (
          <JimuMapViewComponent
            useMapWidgetId={this.props.useMapWidgetIds[0]}
            onActiveViewChange={this.activeViewChangeHandler}
          />
        ) : (
          <p>Please select a map.</p>
        )}
      </div>
    );
  }
}
